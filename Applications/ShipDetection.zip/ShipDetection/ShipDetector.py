from keras.models import load_model
from PIL import Image 
import matplotlib.pyplot as plt  
import numpy as np
import os 
import tensorflow as tf
from skimage.morphology import binary_opening, disk
from skimage.io import imread,imshow
 
model_path = ''
image_path = ''

def predictraw(image_path,model_path):
    model = load_model(model_path)
    c_img = Image.open(image_path)
    c_img = np.expand_dims(c_img, 0)/255.0
    cur_seg = model.predict(c_img)[0]
    return cur_seg


def smooth(pred_raw):
    return binary_opening(pred_raw>0.99, np.expand_dims(disk(2), -1))

def predict(image_path,model_path):
    predictimage = predictraw(image_path,model_path)
    return smooth(predictimage)
    

model_path = '/Users/zifanwang/Downloads/fullres_model.h5'
image_path = '/Users/zifanwang/Documents/ship1.jpg'
predict_image = predict(image_path,model_path)
imshow(predict_image[:,:,0])